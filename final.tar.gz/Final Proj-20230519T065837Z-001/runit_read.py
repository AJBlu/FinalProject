import subprocess
import csv
import re

header=['filesystem','filesize','time', 'blocksize']
filesystem_type = ['ext4', 'fat32', 'btrfs', 'ext2', 'xfs']
true_size = ['1MB', '10MB', '100MB', '1GB']

file_size = [['1MB', '10MB', '100MB', '1GB'], 
			['512KB', '5MB', '50MB', '512MB'], 
			['256KB', '2560KB', '25MB', '256MB'], 
			['128KB', '1280KB', '12800KB', '128MB'] ]
count = [1, 2, 4, 8]



read_to = ["of=/mnt/ext4/sample.txt", "of=/mnt/fat32/sample.txt", "of=/mnt/btrfs/sample.txt", "of=/mnt/ext2/sample.txt", "of=/mnt/xfs/sample.txt"]
random = ["/mnt/ext4/sample.txt", "/mnt/vfat/sample.txt", "/mnt/btrfs/sample.txt", "/mnt/ext2/sample.txt", "/mnt/xfs/sample.txt"]



#begin csv file with header


#reading

for z in range(0, 5):

	for y in range(0, 4):
		f = open('write_data/data_' + filesystem_type[z] + true_size[y] + '.csv', 'w')
		writer  = csv.writer(f)
		writer.writerow(header)
		for blocksize in range (0,4):
			bs = "bs=" + file_size[y][blocksize]
			file_count = "count=" + str(count[y])

			for x in range (0, 385): #needed sample size for 95% confidence, 10% stdev, 1s standard error

				subprocess.run(["sudo", "./clearcache.sh"]) #clear cache every write
				out_line = subprocess.run(["sudo", "dd", "if=/dev/random", read_to[z], bs, file_count], 
					capture_output=True, text=True)
				lines = out_line.stderr.split(",")
				print(lines)
				time = lines[-2]
				stripped_time = re.findall("\d*\.*\d+(?:e-?\d+)?", time)
				row = [filesystem_type[z], true_size[blocksize], stripped_time[0], file_size[y][blocksize] ]
				print(row)
				#subprocess.run(["sudo", "rm", random[z] ])
				writer.writerow(row)
		f.close()



